
=====================================================================================================
Config-Nomad  v5.1 - Nomad.cfg
��� Written by Austin "Nomad" Davis ���
Visit #Nomad @ Gamesnet
=====================================================================================================

For installation unzip the download to your rtcw/main folder and rename your current wolfconfig_mp.cfg in your OSP, shrubmod, and main folders to "backupcfg.cfg". Next create a file in your /main folder called "autoexec.cfg" and add to the 1st line the following: exec nomad.cfg

Ok, so you've taken the time to download this config and even went so far as to read the readme file. Congrats! This file should show you everything about this config, the work put into it, ideas it's based on, and go as far as to teach you just about everything there is to know about scripting and configing in RTC Wolfenstein.

I've spent the last year playing Wolf and I've come by many things. There's all kinds of configs out there, and an unlimited number of configurations one is liable to use for play. In the past I've tried to find the best possible config out there, and after many hours of searching and testing the only thing I can conclude is there's no one perfect config. Configs are perfect only by bases of the player's idea of perfect. Whether the player chooses to tweak the ever living daylights out of a config or just perfers to stick with a basic and simple class select script what it takes to make the one true perfect config is making it fit accordingly to everyone.

With that in mind, I have, over the past eight months, tried to develop a config that is seemingly perfect for every player; one that provides excellent visibility, a class selecter, an armory of premade and ready at the touch of a button scripts, and above all easy and fast customization. This file is not only a perfect config set for many people, but it's also a starter's guide for anyone who wants to learn how to script. That is what I've worked for, and with the release of this file I think I have acheived my goal.

Ok then, let's get started. If you need information on any single config file, do a search within this readme for a tilde (~) and the name of the file. (i.e. ~configname)

~personal.cfg

The first config that I'll start going over is one of the most important, the personal config. In order for you to feel comfortable with this new config, you're going to have to change a few things to make it fit your style of play. As you know some people use asdw while others use the arrow keys, and some even take it so far as to using fghj for movement. Everyone has their own style and editing the personal config is nessesary. So, let's get down to business with it.

When you first open the personal.cfg you'll see the usual heading with the name "Config-Nomad  v5.1 - Personal.cfg" at the center. This file is broken into two parts; the first being settings, and the second being binds. The settings include the sections Name Color Schemes, Basic Settings, and Mouse settings. 

First things being first, you must change the names in the Name Color Schemes section. I surely don't want somone running around smurfing my name, so please make sure you make these changes. =D Keep in mind changes here will have an effect on the way your name matches your spawn script. Where it says redname, enter a name with a basic "RED" color scheme. Where it says greenname, enter a name that has an overall "GREEN" scheme, and so on. Continue to do this for all the colors you'ld like. Written into the mini-configs.cfg is the actual script that reads these lines. When you change the scheme of your name, your class select script will adhere to the new theme! So, when you're using a black name, your class select script will display black text to your team. If you want 2 red schemes for example, read the section on the mini-configs.cfg and it'll explain all about how to do that.

The second section is your basic settings. If you're looking for a setting that alters the way your interface looks, this is where you'll find it. Everything from your crosshair to your modem and back to your team chat height is listed here. Go through and change the settings to your hearts desire.

The third section in the personal config holds the settings that alter your mouse. Only the first two are really used and should be of any concern but I added the other four just in case. Each setting has a description and should be easy to understand.

Now we're getting to the second part of the personal config, the binds. This is broken into two sub-sections; Basic gameplay binds, and the ones dealing with scripts. These should be changed to help you feel more at home with your new config. Each and every bind listed is explained in full so you will not be lost amidst the masses of commands. The Basic binds are, for the most part, nessesary for gameplay. While the script binds are more for quick actions and such. The script binds are all optional and can be changed by editing the key association or removed by adding a double slash ("//")to the begining of the line.

~nomad_client.cfg

Most of this file has been moved to the personal.cfg, but what remains of it is a list of all the settings in RTC Wolfenstein that begin with "cl_". I couldn't think why any of the settings other than cl_pitchspeed because there's a neat little trick you can pull using a script that changes this variable. Other than that, this file should remain unchanged. Oh, and if you diable cl_packetdup then packets that are dropped will not automatically resend... so it could create lag via packetloss.

~nomad_memory.cfg

Now we come to the memory management section of these configs. The nomad_memory.cfg contains the settings that alter the way your computer allocates memory for RTC Wolfenstein. Here's some helpful hints for setting these. com_maxfps should be set to either 43 76 or 125 depending on how often you keep your fps on those numbers. If you are able to hold 76, but are constantly forced to drop to 43, then set it to 43. Same goes with 125 and 76. com_hunkMegs should be set to a total of 1/2 your availible RAM. You can go higher but never over 3/4 your total RAM. com_zoneMegs determines how much memory to allocate for map and texture loading. 16 for 128 megs of RAM, 32 for 256+ megs of RAM. com_soundMegs should be either 24 or 32 based on the remaining RAM you have availible after allocating it for hunks and zones.

~nomad_mini-configs.cfg

Ok, now we've hit the mother of all scripts. The nomad_mini-configs.cfg houses the code for all the variables and togglers other than those set by the classes scripts. This is broken into a section for each of the scripts. I'll explain what each one does, how it does it, and how to change it. **Note all variables start with q_ so typing q_ and then pressing TAB will display a list of all variables. **

	1st - binocular Toggler
By default the binoculars used by a Lieutenant that usually require you to hold the B key down have been replaced by a toggle script. This script allows a player to have the binoculars stay on after releasing the B key, and they go away either when the player presses the B key again or fires a mortar marker. It works just like any toggler. You bind a key to part A (the toggle variable). Part A is set to look at part B (binocs on + bind mouse1 vstr q_binoon) until part B is initiated. When it is Part B sets Part A to look at Part C (turns binoculars off + bind Mouse1 +attack). And when Part C is initiated it resets back to the start. In this particular one there's also a Part D (firing a mortar marker) that cancels both part A and B out and resets part C to A again. This is a 2 step cycler with a failsafe.

	2nd - The Qsays
Ok, everyone has these in one form or another. You're in trouble, you need help, you get killed, and an engineer starts planting dyno. It takes just too long to type out "engineer planting" so you bind it to a key. That's exactly what these are. Except, they've been modified. Most people have their keys bound to either just SAY or to SAY and VSAY. The only problem is, sometimes you need to JUST say and sometimes you need both. And on top of needing to distinguish between the two, I've never seen one that doesn't spam your location. =/ I absolutely hate seeing the following:
[Newguy]Afro-thunder (Axis Submarine(Axis Submarine): <<>>><<!!Engineer planting!!>><<<>>
There's no need to let your team know they're planting at the sub, we already know that... it's a bit rhetorical if you ask me. So I've eliminated that... in some of the cases. As in, when the engineer's planting, it's gone, but if you need a Kill-Revive, it IS there. Not only that but I'ev optimized the use of Vsays. There's no reason to give a vsay message when letting your team know they need to gib, but there is if an engineer is planting (defend the obj). This optimization is very helpful and makes for quick and easy direction given to your team. Really nothing should be changed unless you don't like the format or the vsay command used. You can easily change the key these are bound to by looking in your Personal.cfg in the "Binds used by mini-configs" section.

	3rd - Name-Change
This is a cycler script initiated by pressing the q_nextname key bound in your "personal.cfg". The actual NAMES that are used are also listen in your personal.cfg at the very begining. The cycler will first display an example of the upcoming name, and if it's the desired one pressing the confirmation key will activate it. (This is a B through G sets A and H initiates A cycler.) As I mentioned earlier in this file this was designed so that making a name with a black scheme will change the scheme of your repsawn config. So matching up the scheme with the designated line in your personal config isn't any hard. I also mentioned that I'ld explain how to have more than one name use the same scheme. That's easy enough. First come up with the two names you'ld like to use. Define them in the personal.cfg with 2 lines that look like the following:
set redname1 "name ^1Nomad"
set redname2 "name ^1N^7oma^1d" 
Next look in the upper part of the name-change section in your mini-configs.cfg file a part that says "echo name: ^1Red;" Where it says ^1Red (or if you'ld like to use any other slot, look at the corrisponding color spot) change that to something that identifies the 1st name that uses the red scheme, like "echo name: ^1Red^7#1". Then change the next line below that slot from ^2Green (or whatever is right below the original line you changed) to "echo name: ^1Red^7#2" (Leave quotes out! Don't change their position!) Now, at the bottom of the Name-Change section of the mini-configs.cfg there's a line that corrosponds with the two lines that you just changed. (q_nameecho1 goes with q_name1, q_nameecho2 goes with q_name2, and so on.) Edit the part of those lines that says "vstr redname" and "vstr greenname" to read "vstr redname1" and "vstr redname2". Finally change the part that says "cfgn/classes/green to the corrosponding color you're interested in using. In this case you'ld change it to red. There you have it!
Here's a quick example of all that:

// personal.cfg
set redname1 "name ^1Nomad"
set redname2 "name ^1N^7oma^1d" 
//nomad_mini-configs.cfg
set "q_nameecho1" "echo  ; echo  ; echo name: ^1Red^7#1;		set q_sayname vstr q_name1; set q_nextname vstr q_nameecho2"
set "q_nameecho2" "echo  ; echo  ; echo name: ^1Red^7#2;		set q_sayname vstr q_name2; set q_nextname vstr q_nameecho3"
set "q_name1" "exec cfgn/classes/red; vstr redname1"
set "q_name2" "exec cfgn/classes/red; vstr redname2"


	4th - FPS Cycle
Some people have trouble playing with 125 or 76 frames per second 100% of the time, and they don't want to give up the beauty and smoothness by locking it at 43. So they use an FPS cycler. The default binded key for this is "H" and can be changed to whatever you'ld like in the personal.cfg. This is a simple cycler (A to B, B to C, and C back to A) that will cycle through 125, 76, or 43 frames per second depending on what you need at the time. **NOTE this does not work in any shrub, Banimod, default, or any other server that runs a mod other than OSP.

	5th - Volume
Sometimes people need more sound in-game, and sometimes you just... don't. That's what I created this for. The default keys for this are you left and right arrows, but can be easily changed from within your personal.cfg. Pressing leftarrow turns the volume down and righarrow turns it back up. The cycler sets 2 different variables. One that prepares to turn the volume up next, and one that prepares to turn it down next. It's much like a hybrid between the binocular cycler (without the failsafe reset) and the name changer (without the confirmation key). This cycle's design allows you to go both back and forward through the cycle, while other cycles like the FPS cycle or the Name-Change cycle only allow you to go in one direction, and passing up the desired setting requires you to go all the way back through. 

	6th - FOV Cycler	
As you may know somone's field of vision greatly affects their style of play. Generally players with low FOV settings tend to be better at long range, while ones with High settings fair better in close combat. The FOV cycler allows you to get the best of both worlds. This cycler works exactly the same as the Volume cycle, and was even designed using the same base-code. The default key to initiate this is by rolling your mouse UP or DOWN. This give you the feel of actually zooming into your target with a sniper rifle, or say binoculars. This cycler might take some customization, however. When I designed it, I only wanted a max of 110 FOV. Some players, however, like to go to either 115 or 120. So I got you covered! As you can see at the end of the FOV Cycler section there's additional lines that say "For 115 max fov" or "For 120 max fov". If you want a max of 115, remove the //s from in front of the 115 section and add them to the 110 section. Same applies for players who use a max of 120. Remove the //s from the 120 section and add them to the 110 section.

	7th - Run/Walk Toggler
Smart OLTL players caught in a last man battle generally use walk more than they do run. In cases like that holding down a walk key for 5 full minutes can get quite painful. So I created this just in case. It's the same type of toggler as the Binocular toggler but hold the failsafe reset key. In the "unused batch" section of the personal.cfg you'll find the line used to bind this to a key.

	8th - Drawgun changer
Ok, some players perfer using drawgun but only on a few weapons like the needle and ammo/health packs. Others on the... other =/... hand choose to use either drawgun 0 or 1 all the time regardless of the weapon they're weilding. That's where this part comes into play. You'll find in your personal.cfg an extra few lines at the bottom under the "unused batch" section that corrospond to this section. Simply remove the //s from the begining of those lines and add them to the begining of the ORIGINAL lines used to bind the weapons. The original lines are in the "Basic Gameplay Binds" section of your personal config. They are right in a row starting from "bind 1..." to "bind 6...".


~nomad_network.cfg

Unless you know what you're doing... leave these alone. They deal with network settings and sockets so most people should just stay clear.


~nomad_rendering.cfg

Ok, here's where graphics really comes into play. All the settings that change the way that your video card deals with the rendering tasks in Wolfenstein are listed in here. As always it's separated into sections. The first section being the thirteen most commonly changed settings, and the second section being the other fifty or so that are usually overlooked. Change any one of these settings to better fit your computer's capablities. If your monitor shuts off every time you load Wolfenstein change your r_displayRefresh to a lower number. Changing these settings could give you an OpenGL error. In that case just reset it to what you were originally getting. IF WHEN YOU GET THIS CONFIG you start getting an OpenGL error, you could either remove the nomad_rendering.cfg and add your own rendering settings from your own config, or you could go through the process of elimination and remove the one or two settings that are giving you problems.

~nomad_server.cfg 

Here we have all the settings you're going to need to change in order to run a server on your machine. If you're running a DSL/Cable modem you should be able to squeze a two to four client server using these settings. If you feel you need to change a setting feel free to do so, nothing here can really harm your computer. So don't be afraid to try a few things out.

~nomad_sound.cfg

The sound config is home to the settings that, yeah you guessed it, the sound settings. =/ Changing these to your comfort zone should be based directly from your old config. Don't go trying to wild card guess with these settings because a few of them are very sensitive to change.

~nomad_UserInterface.cfg
These settings change menus, fonts, and things dealing with your favorites list. Don't change them. 

~classes

This isn't actually one config, but a group of them found in the cfgn/classes folder. This script uses 4 keys, f9-12, to select your Classes. I've layed everything out to be as simple and quick as possible. For the classes Lieut and Soldier, you have to press the button twice. Once to select the class, and a second time to select your weapon.
	f9  - Soldier
		f9  - Panzer
		f10 - Sniper
		f11 - Flamer
		f12 - Venom
	f10 - Lieutenant
		f9  - Thompson
		f10 - MP40
		f11 - Sten
	f11 - Engineer
	f12 - Medic
This means that pressing f9 twice will select a panzer, but pressing f9 then f10 will select a sniper. I chose this layout because I felt pressing a button twice was faster than pressing 2 buttons once each. What I mean by that is since MOST people use an MP40 as a lieutenant instead of a thompson, I made it so that pressing f10 twice would do that. Instead of having to press f10 then press f9 or whatever. The same goes for a soldier. Not Many people use a venom, or flamethrower, so they were put farther out to save room for the other quick class binds. 

After I did all of this I went back and created multiple copies of this config and changed the color scheme and started making some other improvements. So not only is this class selecter dynamic to your name scheme but it is also the combination of the absolute best configing work you'll find and more. As I said before, I absolutely can't stand location spam. Nobody cares that you're in the basement when you deside you're going to go sniper... They just want to know that you ARE GOING SNIPER. So, I removed the location spam that's associated with that. There's only one problem with this, however. By removing the location spam, teammates will not see the message if you're not playing in OSP and neither will you. So I added an extra feature to help you out. I added a limbo spawn message. You've seen it before. It says, "You will spawn as an Axis Lieutenant with an MP40." or whatever class/team/weapon you chose. So, wether you're playing shrub, bani, WW, or default you'll know what class you're getting ready to spawn as. 

That's it. If you've taken the time to read this entire file, and look over the configs while doing it not only should you understand exactly how to use each one, but you should also be able to start creating your own scripts and configs. I hope you can enjoy the work I've put into it, and appreciate the use you'll get out of it. For any questions, comments, or well just about anything that you'ld like to add you can email me at "austinleedavis(nospam)@hotmail.com". [Just don't forget to remove the part that says "(nospam)".] Or catch me in mIRC at "#nomad". 


Just for anyone who was wondering it took me the greater part of seven hours to write this readme. =D